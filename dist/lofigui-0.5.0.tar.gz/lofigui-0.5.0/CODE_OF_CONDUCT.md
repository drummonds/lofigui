# Contributor Covenant Code of Conduct

## Our Pledge

We pledge to make participation in our project a harassment-free experience for everyone.

## Our Standards

Positive behavior includes:
- Being respectful
- Accepting constructive criticism
- Focusing on what's best for the community
- Showing empathy

Unacceptable behavior includes:
- Harassment or discrimination
- Trolling or insulting comments
- Publishing others' private information
- Unprofessional conduct

## Enforcement

Report unacceptable behavior to the project owner.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1.
