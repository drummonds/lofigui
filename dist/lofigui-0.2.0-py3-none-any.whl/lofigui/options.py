

# <div class = "checkbox">
#                <label class = "is-size-5">Fruits</label>
#                <br>
#                <label class = "checkbox">
#                   <input type = "checkbox">
#                   Orange
#                </label>
               
#                <label class = "checkbox">
#                   <input type = "checkbox">
#                   Apple
#                </label>
               
#                <label class = "checkbox">
#                   <input type = "checkbox">
#                   Grapes
#                </label>
               
#                <label class = "checkbox">
#                   <input type = "checkbox">
#                   Mango
#                </label>
#             </div>